import google.generativeai as genai
import time

class colors:
    RESET = '\033[0m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

genai.configure(api_key="AIzaSyD27VpBDVwbz1zbtq4QmoQtYegvgE0ypWM")
model = genai.GenerativeModel("gemini-1.5-flash")

def print_slow(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.03)  # Adjust the delay (in seconds) to control the speed of text output
    print()

while True:
    input_user = input("You: ")
    if input_user.lower() == "exit":
        break
    
    response = model.generate_content([input_user])
    ai_response = response.text.strip()  # Mengambil respons dari model dan menghapus spasi ekstra di sekitar teks
    
    print(colors.BLUE + "Dav|AI:" + colors.RESET, end=' ')
    print_slow(colors.GREEN + ai_response + colors.RESET)
    print("\nketik 'exit' untuk mengakhiri chat")
